module.exports = {
 DB_URI: 'mongodb+srv://test:testtest@cluster0-cx1xu.mongodb.net/test?retryWrites=true&w=majority',
 SECRET: 'nafipuhbrp',
 AWS_ACCESS_KEY_ID: 'AKIAJ7VUZYOMVEUCSCQQ',
 AWS_SECRET_ACCESS_KEY: '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',
 STRIPE_SK: 'sk_test_jXsRjOIJNXS6gPmu8hiiypsG00iW7ldShh'
}
